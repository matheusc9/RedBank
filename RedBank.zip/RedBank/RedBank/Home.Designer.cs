﻿namespace RedBank
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            guna2ControlBox2 = new Guna.UI2.WinForms.Guna2ControlBox();
            guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(components);
            labelWelcome = new Guna.UI2.WinForms.Guna2HtmlLabel();
            labelBank = new Guna.UI2.WinForms.Guna2HtmlLabel();
            labelRed = new Guna.UI2.WinForms.Guna2HtmlLabel();
            labelFooter = new Guna.UI2.WinForms.Guna2HtmlLabel();
            labelSaldo = new Guna.UI2.WinForms.Guna2HtmlLabel();
            containerContaInfo = new Guna.UI2.WinForms.Guna2Shapes();
            buttonTransferir = new Guna.UI2.WinForms.Guna2Button();
            buttonHide = new Guna.UI2.WinForms.Guna2Button();
            circleConta = new Guna.UI2.WinForms.Guna2Shapes();
            buttonDepositar = new Guna.UI2.WinForms.Guna2Button();
            buttonHistorico = new Guna.UI2.WinForms.Guna2Button();
            panelTransferir = new Guna.UI2.WinForms.Guna2Panel();
            btnClosePanelTransferir = new Guna.UI2.WinForms.Guna2Button();
            btnTransferirValor = new Guna.UI2.WinForms.Guna2Button();
            inputDestinoTransferir = new Guna.UI2.WinForms.Guna2TextBox();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            inputValorTransferir = new Guna.UI2.WinForms.Guna2TextBox();
            panelDepositar = new Guna.UI2.WinForms.Guna2Panel();
            btnClosePanelDepositar = new Guna.UI2.WinForms.Guna2Button();
            btnDepositarValor = new Guna.UI2.WinForms.Guna2Button();
            labelPanelDepositar = new Guna.UI2.WinForms.Guna2HtmlLabel();
            inputValorDepositar = new Guna.UI2.WinForms.Guna2TextBox();
            listBoxHistorico = new ListBox();
            panelTransferir.SuspendLayout();
            panelDepositar.SuspendLayout();
            SuspendLayout();
            // 
            // guna2ControlBox2
            // 
            guna2ControlBox2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            guna2ControlBox2.BorderRadius = 5;
            guna2ControlBox2.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            guna2ControlBox2.CustomIconSize = 15F;
            guna2ControlBox2.CustomizableEdges = customizableEdges1;
            guna2ControlBox2.FillColor = Color.Transparent;
            guna2ControlBox2.HoverState.FillColor = Color.FromArgb(64, 64, 64);
            guna2ControlBox2.IconColor = Color.White;
            guna2ControlBox2.Location = new Point(797, 0);
            guna2ControlBox2.Name = "guna2ControlBox2";
            guna2ControlBox2.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2ControlBox2.Size = new Size(40, 40);
            guna2ControlBox2.TabIndex = 3;
            // 
            // guna2ControlBox1
            // 
            guna2ControlBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            guna2ControlBox1.BorderRadius = 5;
            guna2ControlBox1.CustomIconSize = 15F;
            guna2ControlBox1.CustomizableEdges = customizableEdges3;
            guna2ControlBox1.FillColor = Color.Transparent;
            guna2ControlBox1.HoverState.FillColor = Color.Maroon;
            guna2ControlBox1.IconColor = Color.White;
            guna2ControlBox1.Location = new Point(843, 0);
            guna2ControlBox1.Name = "guna2ControlBox1";
            guna2ControlBox1.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2ControlBox1.Size = new Size(40, 40);
            guna2ControlBox1.TabIndex = 2;
            // 
            // guna2BorderlessForm1
            // 
            guna2BorderlessForm1.BorderRadius = 20;
            guna2BorderlessForm1.ContainerControl = this;
            guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            guna2BorderlessForm1.DragStartTransparencyValue = 1D;
            guna2BorderlessForm1.ResizeForm = false;
            guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // labelWelcome
            // 
            labelWelcome.BackColor = Color.Transparent;
            labelWelcome.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelWelcome.ForeColor = SystemColors.ButtonShadow;
            labelWelcome.IsSelectionEnabled = false;
            labelWelcome.Location = new Point(12, 94);
            labelWelcome.Name = "labelWelcome";
            labelWelcome.Size = new Size(284, 34);
            labelWelcome.TabIndex = 8;
            labelWelcome.Text = "Bem vindo(a) ao RedBank!";
            // 
            // labelBank
            // 
            labelBank.BackColor = Color.Transparent;
            labelBank.Font = new Font("Segoe UI", 48F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelBank.ForeColor = Color.WhiteSmoke;
            labelBank.IsSelectionEnabled = false;
            labelBank.Location = new Point(117, 12);
            labelBank.Name = "labelBank";
            labelBank.Padding = new Padding(3);
            labelBank.Size = new Size(147, 94);
            labelBank.TabIndex = 7;
            labelBank.Text = "Bank";
            // 
            // labelRed
            // 
            labelRed.BackColor = Color.Transparent;
            labelRed.Font = new Font("Segoe UI", 48F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelRed.ForeColor = Color.Maroon;
            labelRed.IsSelectionEnabled = false;
            labelRed.Location = new Point(12, 12);
            labelRed.Name = "labelRed";
            labelRed.Padding = new Padding(3);
            labelRed.Size = new Size(118, 94);
            labelRed.TabIndex = 6;
            labelRed.Text = "Red";
            // 
            // labelFooter
            // 
            labelFooter.BackColor = Color.Transparent;
            labelFooter.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelFooter.ForeColor = SystemColors.ButtonShadow;
            labelFooter.IsSelectionEnabled = false;
            labelFooter.Location = new Point(803, 530);
            labelFooter.Name = "labelFooter";
            labelFooter.Size = new Size(69, 19);
            labelFooter.TabIndex = 11;
            labelFooter.Text = "© RedBank";
            // 
            // labelSaldo
            // 
            labelSaldo.BackColor = Color.Transparent;
            labelSaldo.Font = new Font("Segoe UI", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelSaldo.ForeColor = Color.White;
            labelSaldo.IsSelectionEnabled = false;
            labelSaldo.Location = new Point(12, 150);
            labelSaldo.Name = "labelSaldo";
            labelSaldo.Size = new Size(146, 67);
            labelSaldo.TabIndex = 12;
            labelSaldo.Text = "R$0,00";
            // 
            // containerContaInfo
            // 
            containerContaInfo.BackColor = Color.Transparent;
            containerContaInfo.BorderColor = Color.FromArgb(64, 64, 64);
            containerContaInfo.BorderThickness = 1;
            containerContaInfo.FillColor = Color.FromArgb(33, 33, 33);
            containerContaInfo.Location = new Point(0, 112);
            containerContaInfo.Name = "containerContaInfo";
            containerContaInfo.PolygonSkip = 1;
            containerContaInfo.Rotate = 0F;
            containerContaInfo.RoundedEdges = customizableEdges32;
            containerContaInfo.Shape = Guna.UI2.WinForms.Enums.ShapeType.Rounded;
            containerContaInfo.Size = new Size(883, 139);
            containerContaInfo.TabIndex = 13;
            containerContaInfo.Text = "guna2Shapes1";
            containerContaInfo.UseTransparentBackground = true;
            containerContaInfo.Zoom = 100;
            // 
            // buttonTransferir
            // 
            buttonTransferir.BackColor = Color.Transparent;
            buttonTransferir.BorderRadius = 20;
            buttonTransferir.Cursor = Cursors.Hand;
            buttonTransferir.CustomizableEdges = customizableEdges30;
            buttonTransferir.DisabledState.FillColor = Color.FromArgb(25, 25, 25);
            buttonTransferir.DisabledState.ForeColor = Color.FromArgb(110, 110, 110);
            buttonTransferir.FillColor = Color.FromArgb(40, 40, 40);
            buttonTransferir.Font = new Font("Lucida Sans Unicode", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonTransferir.ForeColor = SystemColors.ButtonShadow;
            buttonTransferir.Location = new Point(12, 271);
            buttonTransferir.Name = "buttonTransferir";
            buttonTransferir.ShadowDecoration.CustomizableEdges = customizableEdges31;
            buttonTransferir.Size = new Size(180, 45);
            buttonTransferir.TabIndex = 14;
            buttonTransferir.Text = "Transferir";
            buttonTransferir.UseTransparentBackground = true;
            buttonTransferir.Click += buttonTransferir_Click;
            // 
            // buttonHide
            // 
            buttonHide.BorderColor = Color.FromArgb(64, 64, 64);
            buttonHide.BorderRadius = 20;
            buttonHide.Cursor = Cursors.Hand;
            buttonHide.CustomizableEdges = customizableEdges28;
            buttonHide.DisabledState.BorderColor = Color.DarkGray;
            buttonHide.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonHide.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonHide.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonHide.FillColor = Color.Transparent;
            buttonHide.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonHide.ForeColor = Color.Gray;
            buttonHide.HoverState.FillColor = Color.FromArgb(30, 30, 30);
            buttonHide.HoverState.ForeColor = SystemColors.Window;
            buttonHide.Location = new Point(836, 115);
            buttonHide.Name = "buttonHide";
            buttonHide.ShadowDecoration.CustomizableEdges = customizableEdges29;
            buttonHide.Size = new Size(38, 33);
            buttonHide.TabIndex = 15;
            buttonHide.Text = "👁️";
            buttonHide.Click += buttonHide_Click;
            // 
            // circleConta
            // 
            circleConta.BackColor = Color.Transparent;
            circleConta.BorderColor = Color.FromArgb(64, 64, 64);
            circleConta.BorderThickness = 1;
            circleConta.Cursor = Cursors.Hand;
            circleConta.FillColor = Color.FromArgb(33, 33, 33);
            circleConta.Location = new Point(822, 46);
            circleConta.Name = "circleConta";
            circleConta.PolygonSkip = 1;
            circleConta.Rotate = 0F;
            circleConta.RoundedEdges = customizableEdges27;
            circleConta.Shape = Guna.UI2.WinForms.Enums.ShapeType.Ellipse;
            circleConta.Size = new Size(50, 50);
            circleConta.TabIndex = 16;
            circleConta.Text = "guna2Shapes2";
            circleConta.UseTransparentBackground = true;
            circleConta.Zoom = 100;
            circleConta.Click += circleConta_Click;
            // 
            // buttonDepositar
            // 
            buttonDepositar.BackColor = Color.Transparent;
            buttonDepositar.BorderRadius = 20;
            buttonDepositar.Cursor = Cursors.Hand;
            buttonDepositar.CustomizableEdges = customizableEdges25;
            buttonDepositar.DisabledState.FillColor = Color.FromArgb(25, 25, 25);
            buttonDepositar.DisabledState.ForeColor = Color.FromArgb(110, 110, 110);
            buttonDepositar.FillColor = Color.FromArgb(40, 40, 40);
            buttonDepositar.Font = new Font("Lucida Sans Unicode", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonDepositar.ForeColor = SystemColors.ButtonShadow;
            buttonDepositar.Location = new Point(198, 271);
            buttonDepositar.Name = "buttonDepositar";
            buttonDepositar.ShadowDecoration.CustomizableEdges = customizableEdges26;
            buttonDepositar.Size = new Size(180, 45);
            buttonDepositar.TabIndex = 17;
            buttonDepositar.Text = "Depositar";
            buttonDepositar.UseTransparentBackground = true;
            buttonDepositar.Click += buttonDepositar_Click;
            // 
            // buttonHistorico
            // 
            buttonHistorico.BackColor = Color.Transparent;
            buttonHistorico.BorderRadius = 20;
            buttonHistorico.Cursor = Cursors.Hand;
            buttonHistorico.CustomizableEdges = customizableEdges23;
            buttonHistorico.DisabledState.FillColor = Color.FromArgb(25, 25, 25);
            buttonHistorico.DisabledState.ForeColor = Color.FromArgb(110, 110, 110);
            buttonHistorico.FillColor = Color.FromArgb(40, 40, 40);
            buttonHistorico.Font = new Font("Lucida Sans Unicode", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonHistorico.ForeColor = SystemColors.ButtonShadow;
            buttonHistorico.Location = new Point(692, 271);
            buttonHistorico.Name = "buttonHistorico";
            buttonHistorico.ShadowDecoration.CustomizableEdges = customizableEdges24;
            buttonHistorico.Size = new Size(180, 45);
            buttonHistorico.TabIndex = 18;
            buttonHistorico.Text = "Histórico";
            buttonHistorico.UseTransparentBackground = true;
            buttonHistorico.Click += buttonHistorico_Click;
            // 
            // panelTransferir
            // 
            panelTransferir.BackColor = Color.FromArgb(30, 30, 30);
            panelTransferir.BorderColor = Color.FromArgb(64, 64, 64);
            panelTransferir.BorderRadius = 5;
            panelTransferir.BorderThickness = 1;
            panelTransferir.Controls.Add(btnClosePanelTransferir);
            panelTransferir.Controls.Add(btnTransferirValor);
            panelTransferir.Controls.Add(inputDestinoTransferir);
            panelTransferir.Controls.Add(guna2HtmlLabel1);
            panelTransferir.Controls.Add(inputValorTransferir);
            panelTransferir.CustomizableEdges = customizableEdges21;
            panelTransferir.Location = new Point(294, 110);
            panelTransferir.Name = "panelTransferir";
            panelTransferir.ShadowDecoration.CustomizableEdges = customizableEdges22;
            panelTransferir.Size = new Size(300, 340);
            panelTransferir.TabIndex = 19;
            panelTransferir.Visible = false;
            // 
            // btnClosePanelTransferir
            // 
            btnClosePanelTransferir.BorderColor = Color.FromArgb(64, 64, 64);
            btnClosePanelTransferir.BorderRadius = 5;
            btnClosePanelTransferir.Cursor = Cursors.Hand;
            btnClosePanelTransferir.CustomizableEdges = customizableEdges13;
            btnClosePanelTransferir.DisabledState.BorderColor = Color.DarkGray;
            btnClosePanelTransferir.DisabledState.CustomBorderColor = Color.DarkGray;
            btnClosePanelTransferir.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnClosePanelTransferir.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnClosePanelTransferir.FillColor = Color.Transparent;
            btnClosePanelTransferir.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnClosePanelTransferir.ForeColor = Color.White;
            btnClosePanelTransferir.HoverState.FillColor = Color.Maroon;
            btnClosePanelTransferir.HoverState.ForeColor = SystemColors.Window;
            btnClosePanelTransferir.Location = new Point(259, 2);
            btnClosePanelTransferir.Name = "btnClosePanelTransferir";
            btnClosePanelTransferir.ShadowDecoration.CustomizableEdges = customizableEdges14;
            btnClosePanelTransferir.Size = new Size(38, 33);
            btnClosePanelTransferir.TabIndex = 20;
            btnClosePanelTransferir.Text = "❌";
            btnClosePanelTransferir.Click += btnClosePanelTransferir_Click;
            // 
            // btnTransferirValor
            // 
            btnTransferirValor.BackColor = Color.Transparent;
            btnTransferirValor.BorderRadius = 20;
            btnTransferirValor.Cursor = Cursors.Hand;
            btnTransferirValor.CustomizableEdges = customizableEdges15;
            btnTransferirValor.DisabledState.FillColor = Color.FromArgb(25, 25, 25);
            btnTransferirValor.DisabledState.ForeColor = Color.FromArgb(110, 110, 110);
            btnTransferirValor.FillColor = Color.FromArgb(40, 40, 40);
            btnTransferirValor.Font = new Font("Lucida Sans Unicode", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnTransferirValor.ForeColor = SystemColors.ButtonShadow;
            btnTransferirValor.Location = new Point(60, 250);
            btnTransferirValor.Name = "btnTransferirValor";
            btnTransferirValor.ShadowDecoration.CustomizableEdges = customizableEdges16;
            btnTransferirValor.Size = new Size(180, 45);
            btnTransferirValor.TabIndex = 20;
            btnTransferirValor.Text = "Transferir";
            btnTransferirValor.UseTransparentBackground = true;
            btnTransferirValor.Click += btnTransferirValor_Click;
            // 
            // inputDestinoTransferir
            // 
            inputDestinoTransferir.BorderColor = Color.FromArgb(64, 64, 64);
            inputDestinoTransferir.BorderRadius = 10;
            inputDestinoTransferir.CustomizableEdges = customizableEdges17;
            inputDestinoTransferir.DefaultText = "";
            inputDestinoTransferir.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            inputDestinoTransferir.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            inputDestinoTransferir.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            inputDestinoTransferir.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            inputDestinoTransferir.FillColor = Color.FromArgb(33, 33, 33);
            inputDestinoTransferir.FocusedState.BorderColor = Color.DimGray;
            inputDestinoTransferir.Font = new Font("Segoe UI", 9F);
            inputDestinoTransferir.ForeColor = Color.DimGray;
            inputDestinoTransferir.HoverState.BorderColor = Color.DimGray;
            inputDestinoTransferir.Location = new Point(20, 150);
            inputDestinoTransferir.Name = "inputDestinoTransferir";
            inputDestinoTransferir.Padding = new Padding(3);
            inputDestinoTransferir.PlaceholderForeColor = Color.FromArgb(64, 64, 64);
            inputDestinoTransferir.PlaceholderText = "Destino (ID)";
            inputDestinoTransferir.SelectedText = "";
            inputDestinoTransferir.ShadowDecoration.CustomizableEdges = customizableEdges18;
            inputDestinoTransferir.Size = new Size(256, 35);
            inputDestinoTransferir.TabIndex = 21;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = Color.White;
            guna2HtmlLabel1.IsSelectionEnabled = false;
            guna2HtmlLabel1.Location = new Point(100, 15);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(103, 34);
            guna2HtmlLabel1.TabIndex = 20;
            guna2HtmlLabel1.Text = "Transferir";
            // 
            // inputValorTransferir
            // 
            inputValorTransferir.BorderColor = Color.FromArgb(64, 64, 64);
            inputValorTransferir.BorderRadius = 10;
            inputValorTransferir.CustomizableEdges = customizableEdges19;
            inputValorTransferir.DefaultText = "";
            inputValorTransferir.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            inputValorTransferir.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            inputValorTransferir.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            inputValorTransferir.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            inputValorTransferir.FillColor = Color.FromArgb(33, 33, 33);
            inputValorTransferir.FocusedState.BorderColor = Color.DimGray;
            inputValorTransferir.Font = new Font("Segoe UI", 9F);
            inputValorTransferir.ForeColor = Color.DimGray;
            inputValorTransferir.HoverState.BorderColor = Color.DimGray;
            inputValorTransferir.Location = new Point(20, 90);
            inputValorTransferir.Name = "inputValorTransferir";
            inputValorTransferir.Padding = new Padding(3);
            inputValorTransferir.PlaceholderForeColor = Color.FromArgb(64, 64, 64);
            inputValorTransferir.PlaceholderText = "Valor";
            inputValorTransferir.SelectedText = "";
            inputValorTransferir.ShadowDecoration.CustomizableEdges = customizableEdges20;
            inputValorTransferir.Size = new Size(256, 35);
            inputValorTransferir.TabIndex = 7;
            // 
            // panelDepositar
            // 
            panelDepositar.BackColor = Color.FromArgb(30, 30, 30);
            panelDepositar.BorderColor = Color.FromArgb(64, 64, 64);
            panelDepositar.BorderRadius = 5;
            panelDepositar.BorderThickness = 1;
            panelDepositar.Controls.Add(btnClosePanelDepositar);
            panelDepositar.Controls.Add(btnDepositarValor);
            panelDepositar.Controls.Add(labelPanelDepositar);
            panelDepositar.Controls.Add(inputValorDepositar);
            panelDepositar.CustomizableEdges = customizableEdges11;
            panelDepositar.Location = new Point(294, 110);
            panelDepositar.Name = "panelDepositar";
            panelDepositar.ShadowDecoration.CustomizableEdges = customizableEdges12;
            panelDepositar.Size = new Size(300, 220);
            panelDepositar.TabIndex = 22;
            panelDepositar.Visible = false;
            // 
            // btnClosePanelDepositar
            // 
            btnClosePanelDepositar.BorderColor = Color.FromArgb(64, 64, 64);
            btnClosePanelDepositar.BorderRadius = 5;
            btnClosePanelDepositar.Cursor = Cursors.Hand;
            btnClosePanelDepositar.CustomizableEdges = customizableEdges5;
            btnClosePanelDepositar.DisabledState.BorderColor = Color.DarkGray;
            btnClosePanelDepositar.DisabledState.CustomBorderColor = Color.DarkGray;
            btnClosePanelDepositar.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnClosePanelDepositar.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnClosePanelDepositar.FillColor = Color.Transparent;
            btnClosePanelDepositar.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnClosePanelDepositar.ForeColor = Color.White;
            btnClosePanelDepositar.HoverState.FillColor = Color.Maroon;
            btnClosePanelDepositar.HoverState.ForeColor = SystemColors.Window;
            btnClosePanelDepositar.Location = new Point(259, 2);
            btnClosePanelDepositar.Name = "btnClosePanelDepositar";
            btnClosePanelDepositar.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnClosePanelDepositar.Size = new Size(38, 33);
            btnClosePanelDepositar.TabIndex = 20;
            btnClosePanelDepositar.Text = "❌";
            btnClosePanelDepositar.Click += btnClosePanelDepositar_Click;
            // 
            // btnDepositarValor
            // 
            btnDepositarValor.BackColor = Color.Transparent;
            btnDepositarValor.BorderRadius = 20;
            btnDepositarValor.Cursor = Cursors.Hand;
            btnDepositarValor.CustomizableEdges = customizableEdges7;
            btnDepositarValor.DisabledState.FillColor = Color.FromArgb(25, 25, 25);
            btnDepositarValor.DisabledState.ForeColor = Color.FromArgb(110, 110, 110);
            btnDepositarValor.FillColor = Color.FromArgb(40, 40, 40);
            btnDepositarValor.Font = new Font("Lucida Sans Unicode", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnDepositarValor.ForeColor = SystemColors.ButtonShadow;
            btnDepositarValor.Location = new Point(60, 150);
            btnDepositarValor.Name = "btnDepositarValor";
            btnDepositarValor.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnDepositarValor.Size = new Size(180, 45);
            btnDepositarValor.TabIndex = 20;
            btnDepositarValor.Text = "Depositar";
            btnDepositarValor.UseTransparentBackground = true;
            btnDepositarValor.Click += btnDepositarValor_Click;
            // 
            // labelPanelDepositar
            // 
            labelPanelDepositar.BackColor = Color.Transparent;
            labelPanelDepositar.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelPanelDepositar.ForeColor = Color.White;
            labelPanelDepositar.IsSelectionEnabled = false;
            labelPanelDepositar.Location = new Point(100, 15);
            labelPanelDepositar.Name = "labelPanelDepositar";
            labelPanelDepositar.Size = new Size(105, 34);
            labelPanelDepositar.TabIndex = 20;
            labelPanelDepositar.Text = "Depositar";
            // 
            // inputValorDepositar
            // 
            inputValorDepositar.BorderColor = Color.FromArgb(64, 64, 64);
            inputValorDepositar.BorderRadius = 10;
            inputValorDepositar.CustomizableEdges = customizableEdges9;
            inputValorDepositar.DefaultText = "";
            inputValorDepositar.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            inputValorDepositar.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            inputValorDepositar.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            inputValorDepositar.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            inputValorDepositar.FillColor = Color.FromArgb(33, 33, 33);
            inputValorDepositar.FocusedState.BorderColor = Color.DimGray;
            inputValorDepositar.Font = new Font("Segoe UI", 9F);
            inputValorDepositar.ForeColor = Color.DimGray;
            inputValorDepositar.HoverState.BorderColor = Color.DimGray;
            inputValorDepositar.Location = new Point(20, 90);
            inputValorDepositar.Name = "inputValorDepositar";
            inputValorDepositar.Padding = new Padding(3);
            inputValorDepositar.PlaceholderForeColor = Color.FromArgb(64, 64, 64);
            inputValorDepositar.PlaceholderText = "Valor";
            inputValorDepositar.SelectedText = "";
            inputValorDepositar.ShadowDecoration.CustomizableEdges = customizableEdges10;
            inputValorDepositar.Size = new Size(256, 35);
            inputValorDepositar.TabIndex = 7;
            // 
            // listBoxHistorico
            // 
            listBoxHistorico.BackColor = Color.FromArgb(30, 30, 30);
            listBoxHistorico.BorderStyle = BorderStyle.FixedSingle;
            listBoxHistorico.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            listBoxHistorico.ForeColor = SystemColors.ButtonShadow;
            listBoxHistorico.FormattingEnabled = true;
            listBoxHistorico.ItemHeight = 20;
            listBoxHistorico.Location = new Point(294, 110);
            listBoxHistorico.Name = "listBoxHistorico";
            listBoxHistorico.SelectionMode = SelectionMode.None;
            listBoxHistorico.Size = new Size(300, 322);
            listBoxHistorico.TabIndex = 21;
            listBoxHistorico.Visible = false;
            // 
            // Home
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(33, 33, 33);
            ClientSize = new Size(884, 561);
            Controls.Add(listBoxHistorico);
            Controls.Add(panelDepositar);
            Controls.Add(panelTransferir);
            Controls.Add(buttonHistorico);
            Controls.Add(buttonDepositar);
            Controls.Add(circleConta);
            Controls.Add(buttonHide);
            Controls.Add(buttonTransferir);
            Controls.Add(labelSaldo);
            Controls.Add(labelFooter);
            Controls.Add(labelWelcome);
            Controls.Add(labelBank);
            Controls.Add(labelRed);
            Controls.Add(guna2ControlBox2);
            Controls.Add(guna2ControlBox1);
            Controls.Add(containerContaInfo);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Home";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Home";
            Load += Home_Load;
            panelTransferir.ResumeLayout(false);
            panelTransferir.PerformLayout();
            panelDepositar.ResumeLayout(false);
            panelDepositar.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox2;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2HtmlLabel labelWelcome;
        private Guna.UI2.WinForms.Guna2HtmlLabel labelBank;
        private Guna.UI2.WinForms.Guna2HtmlLabel labelRed;
        private Guna.UI2.WinForms.Guna2HtmlLabel labelFooter;
        private Guna.UI2.WinForms.Guna2HtmlLabel labelSaldo;
        private Guna.UI2.WinForms.Guna2Shapes containerContaInfo;
        private Guna.UI2.WinForms.Guna2Button buttonTransferir;
        private Guna.UI2.WinForms.Guna2Button buttonHide;
        private Guna.UI2.WinForms.Guna2Shapes circleConta;
        private Guna.UI2.WinForms.Guna2Button buttonDepositar;
        private Guna.UI2.WinForms.Guna2Button buttonHistorico;
        private Guna.UI2.WinForms.Guna2Panel panelTransferir;
        private Guna.UI2.WinForms.Guna2Button btnTransferirValor;
        private Guna.UI2.WinForms.Guna2TextBox inputDestinoTransferir;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2TextBox inputValorTransferir;
        private Guna.UI2.WinForms.Guna2Button btnClosePanelTransferir;
        private Guna.UI2.WinForms.Guna2Panel panelDepositar;
        private Guna.UI2.WinForms.Guna2Button btnClosePanelDepositar;
        private Guna.UI2.WinForms.Guna2Button btnDepositarValor;
        private Guna.UI2.WinForms.Guna2HtmlLabel labelPanelDepositar;
        private Guna.UI2.WinForms.Guna2TextBox inputValorDepositar;
        private ListBox listBoxHistorico;
    }
}