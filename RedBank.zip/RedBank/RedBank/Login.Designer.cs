﻿namespace RedBank
{
    partial class Login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(components);
            guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            guna2ControlBox2 = new Guna.UI2.WinForms.Guna2ControlBox();
            labelRed = new Guna.UI2.WinForms.Guna2HtmlLabel();
            labelBank = new Guna.UI2.WinForms.Guna2HtmlLabel();
            pictureBox1 = new PictureBox();
            labelBemVindo = new Guna.UI2.WinForms.Guna2HtmlLabel();
            inputCPF = new Guna.UI2.WinForms.Guna2TextBox();
            loginBackground = new Guna.UI2.WinForms.Guna2Shapes();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            labelFooter = new Guna.UI2.WinForms.Guna2HtmlLabel();
            buttonLogin = new Guna.UI2.WinForms.Guna2Button();
            inputSenha = new Guna.UI2.WinForms.Guna2TextBox();
            checkboxManterLogin = new Guna.UI2.WinForms.Guna2CheckBox();
            buttonViewPass = new Guna.UI2.WinForms.Guna2Button();
            labelInvalid = new Guna.UI2.WinForms.Guna2HtmlLabel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // guna2BorderlessForm1
            // 
            guna2BorderlessForm1.BorderRadius = 20;
            guna2BorderlessForm1.ContainerControl = this;
            guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            guna2BorderlessForm1.DragStartTransparencyValue = 1D;
            guna2BorderlessForm1.ResizeForm = false;
            guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // guna2ControlBox1
            // 
            guna2ControlBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            guna2ControlBox1.BorderRadius = 5;
            guna2ControlBox1.CustomIconSize = 15F;
            guna2ControlBox1.CustomizableEdges = customizableEdges11;
            guna2ControlBox1.FillColor = Color.Transparent;
            guna2ControlBox1.HoverState.FillColor = Color.Maroon;
            guna2ControlBox1.IconColor = Color.White;
            guna2ControlBox1.Location = new Point(843, 0);
            guna2ControlBox1.Name = "guna2ControlBox1";
            guna2ControlBox1.ShadowDecoration.CustomizableEdges = customizableEdges12;
            guna2ControlBox1.Size = new Size(40, 40);
            guna2ControlBox1.TabIndex = 0;
            // 
            // guna2ControlBox2
            // 
            guna2ControlBox2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            guna2ControlBox2.BorderRadius = 5;
            guna2ControlBox2.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            guna2ControlBox2.CustomIconSize = 15F;
            guna2ControlBox2.CustomizableEdges = customizableEdges9;
            guna2ControlBox2.FillColor = Color.Transparent;
            guna2ControlBox2.HoverState.FillColor = Color.FromArgb(64, 64, 64);
            guna2ControlBox2.IconColor = Color.White;
            guna2ControlBox2.Location = new Point(797, 0);
            guna2ControlBox2.Name = "guna2ControlBox2";
            guna2ControlBox2.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2ControlBox2.Size = new Size(40, 40);
            guna2ControlBox2.TabIndex = 1;
            // 
            // labelRed
            // 
            labelRed.BackColor = Color.Transparent;
            labelRed.Font = new Font("Segoe UI", 48F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelRed.ForeColor = Color.Maroon;
            labelRed.IsSelectionEnabled = false;
            labelRed.Location = new Point(12, 12);
            labelRed.Name = "labelRed";
            labelRed.Padding = new Padding(3);
            labelRed.Size = new Size(118, 94);
            labelRed.TabIndex = 2;
            labelRed.Text = "Red";
            // 
            // labelBank
            // 
            labelBank.BackColor = Color.Transparent;
            labelBank.Font = new Font("Segoe UI", 48F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelBank.ForeColor = Color.WhiteSmoke;
            labelBank.IsSelectionEnabled = false;
            labelBank.Location = new Point(117, 12);
            labelBank.Name = "labelBank";
            labelBank.Padding = new Padding(3);
            labelBank.Size = new Size(147, 94);
            labelBank.TabIndex = 3;
            labelBank.Text = "Bank";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(411, 81);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(426, 427);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // labelBemVindo
            // 
            labelBemVindo.BackColor = Color.Transparent;
            labelBemVindo.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelBemVindo.ForeColor = SystemColors.ButtonShadow;
            labelBemVindo.IsSelectionEnabled = false;
            labelBemVindo.Location = new Point(12, 101);
            labelBemVindo.Name = "labelBemVindo";
            labelBemVindo.Size = new Size(284, 34);
            labelBemVindo.TabIndex = 5;
            labelBemVindo.Text = "Bem vindo(a) ao RedBank!";
            // 
            // inputCPF
            // 
            inputCPF.BorderColor = Color.FromArgb(64, 64, 64);
            inputCPF.BorderRadius = 10;
            inputCPF.CustomizableEdges = customizableEdges7;
            inputCPF.DefaultText = "";
            inputCPF.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            inputCPF.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            inputCPF.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            inputCPF.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            inputCPF.FillColor = Color.FromArgb(33, 33, 33);
            inputCPF.FocusedState.BorderColor = Color.DimGray;
            inputCPF.Font = new Font("Segoe UI", 9F);
            inputCPF.ForeColor = Color.DimGray;
            inputCPF.HoverState.BorderColor = Color.DimGray;
            inputCPF.Location = new Point(35, 250);
            inputCPF.Name = "inputCPF";
            inputCPF.Padding = new Padding(0, 0, 0, 20);
            inputCPF.PlaceholderForeColor = Color.FromArgb(64, 64, 64);
            inputCPF.PlaceholderText = "CPF";
            inputCPF.SelectedText = "";
            inputCPF.ShadowDecoration.CustomizableEdges = customizableEdges8;
            inputCPF.Size = new Size(300, 35);
            inputCPF.TabIndex = 6;
            // 
            // loginBackground
            // 
            loginBackground.BorderColor = Color.FromArgb(64, 64, 64);
            loginBackground.FillColor = Color.FromArgb(30, 30, 30);
            loginBackground.Location = new Point(12, 158);
            loginBackground.Name = "loginBackground";
            loginBackground.PolygonSkip = 1;
            loginBackground.Rotate = 0F;
            loginBackground.RoundedEdges = customizableEdges13;
            loginBackground.Shape = Guna.UI2.WinForms.Enums.ShapeType.Rectangle;
            loginBackground.Size = new Size(350, 350);
            loginBackground.TabIndex = 7;
            loginBackground.Text = "guna2Shapes1";
            loginBackground.Zoom = 100;
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.FromArgb(30, 30, 30);
            guna2HtmlLabel2.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            guna2HtmlLabel2.ForeColor = SystemColors.ButtonShadow;
            guna2HtmlLabel2.IsSelectionEnabled = false;
            guna2HtmlLabel2.Location = new Point(35, 179);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(132, 39);
            guna2HtmlLabel2.TabIndex = 9;
            guna2HtmlLabel2.Text = "Faça login!";
            // 
            // labelFooter
            // 
            labelFooter.BackColor = Color.Transparent;
            labelFooter.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelFooter.ForeColor = SystemColors.ButtonShadow;
            labelFooter.IsSelectionEnabled = false;
            labelFooter.Location = new Point(803, 530);
            labelFooter.Name = "labelFooter";
            labelFooter.Size = new Size(69, 19);
            labelFooter.TabIndex = 10;
            labelFooter.Text = "© RedBank";
            // 
            // buttonLogin
            // 
            buttonLogin.BackColor = Color.Transparent;
            buttonLogin.BorderRadius = 20;
            buttonLogin.Cursor = Cursors.Hand;
            buttonLogin.CustomizableEdges = customizableEdges5;
            buttonLogin.DisabledState.FillColor = Color.FromArgb(25, 25, 25);
            buttonLogin.DisabledState.ForeColor = Color.FromArgb(110, 110, 110);
            buttonLogin.FillColor = Color.FromArgb(40, 40, 40);
            buttonLogin.Font = new Font("Lucida Sans Unicode", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonLogin.ForeColor = SystemColors.ButtonShadow;
            buttonLogin.Location = new Point(95, 430);
            buttonLogin.Name = "buttonLogin";
            buttonLogin.ShadowDecoration.CustomizableEdges = customizableEdges6;
            buttonLogin.Size = new Size(180, 45);
            buttonLogin.TabIndex = 11;
            buttonLogin.Text = "Login";
            buttonLogin.UseTransparentBackground = true;
            buttonLogin.Click += buttonLogin_Click;
            // 
            // inputSenha
            // 
            inputSenha.BorderColor = Color.FromArgb(64, 64, 64);
            inputSenha.BorderRadius = 10;
            inputSenha.CustomizableEdges = customizableEdges3;
            inputSenha.DefaultText = "";
            inputSenha.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            inputSenha.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            inputSenha.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            inputSenha.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            inputSenha.FillColor = Color.FromArgb(33, 33, 33);
            inputSenha.FocusedState.BorderColor = Color.DimGray;
            inputSenha.Font = new Font("Segoe UI", 9F);
            inputSenha.ForeColor = Color.DimGray;
            inputSenha.HoverState.BorderColor = Color.DimGray;
            inputSenha.Location = new Point(35, 300);
            inputSenha.Name = "inputSenha";
            inputSenha.Padding = new Padding(0, 0, 0, 20);
            inputSenha.PasswordChar = '●';
            inputSenha.PlaceholderForeColor = Color.FromArgb(64, 64, 64);
            inputSenha.PlaceholderText = "Senha";
            inputSenha.SelectedText = "";
            inputSenha.ShadowDecoration.CustomizableEdges = customizableEdges4;
            inputSenha.Size = new Size(300, 35);
            inputSenha.TabIndex = 12;
            // 
            // checkboxManterLogin
            // 
            checkboxManterLogin.AutoSize = true;
            checkboxManterLogin.BackColor = Color.FromArgb(30, 30, 30);
            checkboxManterLogin.CheckedState.BorderColor = Color.Transparent;
            checkboxManterLogin.CheckedState.BorderRadius = 3;
            checkboxManterLogin.CheckedState.BorderThickness = 0;
            checkboxManterLogin.CheckedState.FillColor = SystemColors.ButtonShadow;
            checkboxManterLogin.CheckMarkColor = Color.FromArgb(64, 64, 64);
            checkboxManterLogin.Cursor = Cursors.Hand;
            checkboxManterLogin.ForeColor = SystemColors.ButtonShadow;
            checkboxManterLogin.Location = new Point(35, 350);
            checkboxManterLogin.Name = "checkboxManterLogin";
            checkboxManterLogin.Size = new Size(94, 19);
            checkboxManterLogin.TabIndex = 13;
            checkboxManterLogin.Text = "Manter login";
            checkboxManterLogin.UncheckedState.BorderColor = Color.Transparent;
            checkboxManterLogin.UncheckedState.BorderRadius = 3;
            checkboxManterLogin.UncheckedState.BorderThickness = 0;
            checkboxManterLogin.UncheckedState.FillColor = Color.FromArgb(64, 64, 64);
            checkboxManterLogin.UseVisualStyleBackColor = false;
            // 
            // buttonViewPass
            // 
            buttonViewPass.BorderColor = Color.FromArgb(64, 64, 64);
            buttonViewPass.BorderRadius = 40;
            buttonViewPass.Cursor = Cursors.Hand;
            buttonViewPass.CustomizableEdges = customizableEdges1;
            buttonViewPass.DisabledState.BorderColor = Color.DarkGray;
            buttonViewPass.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonViewPass.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonViewPass.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonViewPass.FillColor = Color.Transparent;
            buttonViewPass.Font = new Font("Segoe UI", 9F);
            buttonViewPass.ForeColor = Color.Gray;
            buttonViewPass.HoverState.FillColor = Color.FromArgb(30, 30, 30);
            buttonViewPass.HoverState.ForeColor = SystemColors.Window;
            buttonViewPass.Location = new Point(291, 301);
            buttonViewPass.Name = "buttonViewPass";
            buttonViewPass.ShadowDecoration.CustomizableEdges = customizableEdges2;
            buttonViewPass.Size = new Size(38, 33);
            buttonViewPass.TabIndex = 14;
            buttonViewPass.Text = "👁️";
            buttonViewPass.TextAlign = HorizontalAlignment.Right;
            buttonViewPass.Click += buttonViewPass_Click;
            // 
            // labelInvalid
            // 
            labelInvalid.BackColor = Color.Transparent;
            labelInvalid.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelInvalid.ForeColor = Color.Maroon;
            labelInvalid.IsSelectionEnabled = false;
            labelInvalid.Location = new Point(295, 225);
            labelInvalid.Name = "labelInvalid";
            labelInvalid.Size = new Size(40, 19);
            labelInvalid.TabIndex = 15;
            labelInvalid.Text = "Invalid";
            labelInvalid.Visible = false;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(33, 33, 33);
            ClientSize = new Size(884, 561);
            Controls.Add(labelInvalid);
            Controls.Add(buttonViewPass);
            Controls.Add(checkboxManterLogin);
            Controls.Add(inputSenha);
            Controls.Add(buttonLogin);
            Controls.Add(labelFooter);
            Controls.Add(guna2HtmlLabel2);
            Controls.Add(inputCPF);
            Controls.Add(labelBemVindo);
            Controls.Add(pictureBox1);
            Controls.Add(labelBank);
            Controls.Add(labelRed);
            Controls.Add(guna2ControlBox2);
            Controls.Add(guna2ControlBox1);
            Controls.Add(loginBackground);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "Login";
            Opacity = 0.99D;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "RedBank";
            Load += Login_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox2;
        private Guna.UI2.WinForms.Guna2HtmlLabel labelBank;
        private Guna.UI2.WinForms.Guna2HtmlLabel labelRed;
        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2TextBox inputCPF;
        private Guna.UI2.WinForms.Guna2HtmlLabel labelBemVindo;
        private Guna.UI2.WinForms.Guna2Shapes loginBackground;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel labelFooter;
        private Guna.UI2.WinForms.Guna2Button buttonLogin;
        private Guna.UI2.WinForms.Guna2TextBox inputSenha;
        private Guna.UI2.WinForms.Guna2CheckBox checkboxManterLogin;
        private Guna.UI2.WinForms.Guna2Button buttonViewPass;
        private Guna.UI2.WinForms.Guna2HtmlLabel labelInvalid;
    }
}
